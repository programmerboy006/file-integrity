/**
 * File Integrity Monitor
 * 
 * A command-line tool that monitors files in real-time and alerts
 * when unauthorized modifications are detected.
 * 
 * Based on the File Integrity Checker with added monitoring capabilities.
 */

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <sstream>
#include <iomanip>
#include <map>
#include <filesystem>
#include <vector>
#include <cstdint>
#include <thread>
#include <chrono>
#include <mutex>
#include <atomic>
#include <csignal>
#include <limits>

// Define constants
const std::string HASH_DB_FILE = "file_hashes.db";
const std::string MONITOR_LIST_FILE = "monitored_files.txt";
const int DEFAULT_CHECK_INTERVAL = 5; // seconds

// Global variables for monitoring
std::atomic<bool> keepMonitoring(true);
std::mutex filesMutex;

/**
 * CRC32 implementation for file hashing
 */
uint32_t crc32(const uint8_t* data, size_t length) {
    static const uint32_t crc_table[256] = {
        0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f, 0xe963a535, 0x9e6495a3,
        0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988, 0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91,
        0x1db71064, 0x6ab020f2, 0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
        0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9, 0xfa0f3d63, 0x8d080df5,
        0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172, 0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b,
        0x35b5a8fa, 0x42b2986c, 0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
        0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423, 0xcfba9599, 0xb8bda50f,
        0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924, 0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d,
        0x76dc4190, 0x01db7106, 0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
        0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d, 0x91646c97, 0xe6635c01,
        0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e, 0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457,
        0x65b0d9c6, 0x12b7e950, 0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
        0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7, 0xa4d1c46d, 0xd3d6f4fb,
        0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0, 0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9,
        0x5005713c, 0x270241aa, 0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
        0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81, 0xb7bd5c3b, 0xc0ba6cad,
        0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a, 0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683,
        0xe3630b12, 0x94643b84, 0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
        0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb, 0x196c3671, 0x6e6b06e7,
        0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc, 0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5,
        0xd6d6a3e8, 0xa1d1937e, 0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
        0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55, 0x316e8eef, 0x4669be79,
        0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236, 0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f,
        0xc5ba3bbe, 0xb2bd0b28, 0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
        0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f, 0x72076785, 0x05005713,
        0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38, 0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21,
        0x86d3d2d4, 0xf1d4e242, 0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
        0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69, 0x616bffd3, 0x166ccf45,
        0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2, 0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db,
        0xaed16a4a, 0xd9d65adc, 0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
        0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693, 0x54de5729, 0x23d967bf,
        0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94, 0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
    };

    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < length; i++) {
        crc = (crc >> 8) ^ crc_table[(crc ^ data[i]) & 0xFF];
    }
    return crc ^ 0xFFFFFFFF;
}

/**
 * Computes the hash of a file
 * 
 * @param filename Path to the file
 * @return Hash as a hex string, or error message if file not found
 */
std::string computeFileHash(const std::string& filename) {
    std::ifstream file(filename, std::ios::binary);
    if (!file) {
        return "ERROR: File not found";
    }

    // Get file size
    file.seekg(0, std::ios::end);
    std::streamsize fileSize = file.tellg();
    file.seekg(0, std::ios::beg);

    // Read the entire file into a buffer
    std::vector<uint8_t> buffer(fileSize);
    if (!file.read(reinterpret_cast<char*>(buffer.data()), fileSize)) {
        return "ERROR: Could not read file";
    }

    // Compute hash
    uint32_t hashValue = crc32(buffer.data(), buffer.size());
    
    // Convert to hex string
    std::stringstream ss;
    ss << std::hex << std::setw(8) << std::setfill('0') << hashValue;
    
    return ss.str();
}

/**
 * Loads stored hashes from the database file
 * 
 * @return A map of filenames to their hashes
 */
std::map<std::string, std::string> loadHashes() {
    std::map<std::string, std::string> hashes;
    std::ifstream hashFile(HASH_DB_FILE);
    
    if (hashFile) {
        std::string filename, hash;
        while (std::getline(hashFile, filename) && std::getline(hashFile, hash)) {
            hashes[filename] = hash;
        }
    }
    
    return hashes;
}

/**
 * Saves hashes to the database file
 * 
 * @param hashes Map of filenames to their hashes
 */
void saveHashes(const std::map<std::string, std::string>& hashes) {
    std::ofstream hashFile(HASH_DB_FILE);
    
    if (hashFile) {
        for (const auto& pair : hashes) {
            hashFile << pair.first << std::endl;
            hashFile << pair.second << std::endl;
        }
    } else {
        std::cerr << "Error: Could not open hash database file for writing." << std::endl;
    }
}

/**
 * Load the list of files being monitored
 * 
 * @return Vector of file paths being monitored
 */
std::vector<std::string> loadMonitoredFiles() {
    std::vector<std::string> files;
    std::ifstream monitorFile(MONITOR_LIST_FILE);
    
    if (monitorFile) {
        std::string filename;
        while (std::getline(monitorFile, filename)) {
            if (!filename.empty()) {
                files.push_back(filename);
            }
        }
    }
    
    return files;
}

/**
 * Save the list of files being monitored
 * 
 * @param files Vector of file paths to monitor
 */
void saveMonitoredFiles(const std::vector<std::string>& files) {
    std::ofstream monitorFile(MONITOR_LIST_FILE);
    
    if (monitorFile) {
        for (const auto& file : files) {
            monitorFile << file << std::endl;
        }
    } else {
        std::cerr << "Error: Could not open monitor list file for writing." << std::endl;
    }
}

/**
 * Generates and saves a file's hash
 * 
 * @param filename Path to the file
 */
void generateAndSaveHash(const std::string& filename) {
    std::string hash = computeFileHash(filename);
    
    if (hash.substr(0, 6) == "ERROR:") {
        std::cout << hash << std::endl;
        return;
    }
    
    auto hashes = loadHashes();
    
    // Get the absolute path for consistency
    std::filesystem::path absPath = std::filesystem::absolute(filename);
    std::string absolutePath = absPath.string();
    
    hashes[absolutePath] = hash;
    saveHashes(hashes);
    
    std::cout << "Hash computed and saved: " << hash << std::endl;
    std::cout << "For file: " << absolutePath << std::endl;
}

/**
 * Verifies a file's integrity by comparing its current hash with the stored one
 * 
 * @param filename Path to the file
 * @return true if file is intact (unchanged), false if modified or not found
 */
bool verifyFileIntegrity(const std::string& filename, bool verbose = true) {
    std::string currentHash = computeFileHash(filename);
    
    if (currentHash.substr(0, 6) == "ERROR:") {
        if (verbose) {
            std::cout << currentHash << std::endl;
        }
        return false;
    }
    
    auto hashes = loadHashes();
    
    // Get the absolute path for consistency
    std::filesystem::path absPath = std::filesystem::absolute(filename);
    std::string absolutePath = absPath.string();
    
    if (hashes.find(absolutePath) == hashes.end()) {
        if (verbose) {
            std::cout << "No previously saved hash found for this file." << std::endl;
        }
        return false;
    }
    
    std::string savedHash = hashes[absolutePath];
    
    if (verbose) {
        std::cout << "Current hash: " << currentHash << std::endl;
        std::cout << "Saved hash:   " << savedHash << std::endl;
    }
    
    bool isIntact = (currentHash == savedHash);
    
    if (verbose) {
        if (isIntact) {
            std::cout << "File is INTACT!" << std::endl;
        } else {
            std::cout << "ALERT: File has been MODIFIED!" << std::endl;
        }
    }
    
    return isIntact;
}

/**
 * Add a file to the monitoring list
 * 
 * @param filename Path to the file to monitor
 */
void addFileToMonitor(const std::string& filename) {
    // Check if file exists first
    std::string hash = computeFileHash(filename);
    if (hash.substr(0, 6) == "ERROR:") {
        std::cout << hash << std::endl;
        return;
    }
    
    // Get the absolute path
    std::filesystem::path absPath = std::filesystem::absolute(filename);
    std::string absolutePath = absPath.string();
    
    // Check if we have a saved hash, if not create one
    auto hashes = loadHashes();
    if (hashes.find(absolutePath) == hashes.end()) {
        std::cout << "No hash found for this file. Generating one now..." << std::endl;
        generateAndSaveHash(absolutePath);
    }
    
    // Add to monitoring list if not already there
    std::vector<std::string> files = loadMonitoredFiles();
    
    bool alreadyMonitored = false;
    for (const auto& file : files) {
        if (file == absolutePath) {
            alreadyMonitored = true;
            break;
        }
    }
    
    if (!alreadyMonitored) {
        files.push_back(absolutePath);
        saveMonitoredFiles(files);
        std::cout << "File added to monitoring list: " << absolutePath << std::endl;
    } else {
        std::cout << "File is already being monitored." << std::endl;
    }
}

/**
 * Remove a file from the monitoring list
 * 
 * @param filename Path to the file to stop monitoring
 */
void removeFileFromMonitor(const std::string& filename) {
    // Get the absolute path
    std::filesystem::path absPath = std::filesystem::absolute(filename);
    std::string absolutePath = absPath.string();
    
    std::vector<std::string> files = loadMonitoredFiles();
    std::vector<std::string> newFiles;
    
    bool found = false;
    for (const auto& file : files) {
        if (file != absolutePath) {
            newFiles.push_back(file);
        } else {
            found = true;
        }
    }
    
    if (found) {
        saveMonitoredFiles(newFiles);
        std::cout << "File removed from monitoring list: " << absolutePath << std::endl;
    } else {
        std::cout << "File was not in the monitoring list." << std::endl;
    }
}

/**
 * List all files currently being monitored
 */
void listMonitoredFiles() {
    std::vector<std::string> files = loadMonitoredFiles();
    
    if (files.empty()) {
        std::cout << "No files are currently being monitored." << std::endl;
        return;
    }
    
    std::cout << "Files currently being monitored:" << std::endl;
    std::cout << "-------------------------------" << std::endl;
    
    for (size_t i = 0; i < files.size(); i++) {
        std::cout << i + 1 << ". " << files[i] << std::endl;
    }
}

/**
 * Signal handler for graceful termination
 */
void signalHandler(int signum) {
    std::cout << "\nStopping file monitoring..." << std::endl;
    keepMonitoring = false;
}

/**
 * The monitoring thread function
 * Continuously checks monitored files at specified intervals
 * 
 * @param intervalSeconds Time between checks in seconds
 */
void monitoringThread(int intervalSeconds) {
    std::cout << "Starting file monitoring thread..." << std::endl;
    std::cout << "Checking files every " << intervalSeconds << " seconds." << std::endl;
    std::cout << "Press Ctrl+C to stop monitoring." << std::endl;
    
    while (keepMonitoring) {
        // Load the list of files to monitor
        std::vector<std::string> files;
        {
            std::lock_guard<std::mutex> lock(filesMutex);
            files = loadMonitoredFiles();
        }
        
        if (!files.empty()) {
            for (const auto& file : files) {
                // Skip files that don't exist or can't be read
                std::string hash = computeFileHash(file);
                if (hash.substr(0, 6) == "ERROR:") {
                    std::cout << "Warning: " << hash << " - " << file << std::endl;
                    continue;
                }
                
                // Verify integrity without verbose output
                if (!verifyFileIntegrity(file, false)) {
                    auto now = std::chrono::system_clock::now();
                    auto time = std::chrono::system_clock::to_time_t(now);
                    std::cout << "\n[" << std::ctime(&time);
                    std::cout << "ALERT: File has been modified: " << file << std::endl;
                    std::cout << "Current hash: " << hash << std::endl;
                    
                    auto hashes = loadHashes();
                    std::string savedHash = hashes[file];
                    std::cout << "Saved hash:   " << savedHash << std::endl;
                    
                    // Ask user if they want to update the hash
                    std::cout << "Update the saved hash to match the current file? (y/n): ";
                    std::string answer;
                    std::getline(std::cin, answer);
                    
                    if (answer == "y" || answer == "Y") {
                        generateAndSaveHash(file);
                        std::cout << "Hash updated." << std::endl;
                    }
                }
            }
        }
        
        // Sleep for the specified interval
        for (int i = 0; i < intervalSeconds && keepMonitoring; i++) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
    
    std::cout << "File monitoring stopped." << std::endl;
}

/**
 * Start the file monitoring service
 * 
 * @param intervalSeconds Time between checks in seconds
 */
void startMonitoring(int intervalSeconds = DEFAULT_CHECK_INTERVAL) {
    // Register signal handler for Ctrl+C
    std::signal(SIGINT, signalHandler);
    
    // Make sure we have files to monitor
    std::vector<std::string> files = loadMonitoredFiles();
    if (files.empty()) {
        std::cout << "No files are being monitored. Add files first." << std::endl;
        return;
    }
    
    // Reset monitoring flag
    keepMonitoring = true;
    
    // Start monitoring in a separate thread
    std::thread monitor(monitoringThread, intervalSeconds);
    
    // Detach the thread so it can run independently
    monitor.detach();
    
    // Wait for user to press Enter to continue
    std::cout << "Monitoring is running in the background." << std::endl;
    std::cout << "Press Enter to return to the main menu (monitoring will continue)..." << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

/**
 * Displays the interactive menu
 */
void displayMenu() {
    std::cout << "\n============ File Integrity Monitor ============\n";
    std::cout << "1. Generate & Save Hash\n";
    std::cout << "2. Verify File Integrity\n";
    std::cout << "3. Add File to Monitoring\n";
    std::cout << "4. Remove File from Monitoring\n";
    std::cout << "5. List Monitored Files\n";
    std::cout << "6. Start Real-time Monitoring\n";
    std::cout << "7. Exit\n";
    std::cout << "==============================================\n";
    std::cout << "Enter your choice (1-7): ";
}

/**
 * Main function
 */
int main() {
    int choice;
    std::string filename;
    
    std::cout << "Welcome to File Integrity Monitor\n";
    std::cout << "----------------------------------\n";
    
    while (true) {
        displayMenu();
        std::cin >> choice;
        std::cin.ignore(); // Clear the newline character from input buffer
        
        if (choice == 7) {
            // Signal the monitoring thread to stop if it's running
            keepMonitoring = false;
            std::cout << "Exiting program. Goodbye!\n";
            break;
        }
        
        switch (choice) {
            case 1: // Generate & Save Hash
                std::cout << "Enter filename (full path recommended): ";
                std::getline(std::cin, filename);
                generateAndSaveHash(filename);
                break;
                
            case 2: // Verify File Integrity
                std::cout << "Enter filename (full path recommended): ";
                std::getline(std::cin, filename);
                verifyFileIntegrity(filename);
                break;
                
            case 3: // Add File to Monitoring
                std::cout << "Enter filename to monitor (full path recommended): ";
                std::getline(std::cin, filename);
                addFileToMonitor(filename);
                break;
                
            case 4: // Remove File from Monitoring
                std::cout << "Enter filename to stop monitoring (full path recommended): ";
                std::getline(std::cin, filename);
                removeFileFromMonitor(filename);
                break;
                
            case 5: // List Monitored Files
                listMonitoredFiles();
                break;
                
            case 6: { // Start Real-time Monitoring
                std::cout << "Enter check interval in seconds (default: " << DEFAULT_CHECK_INTERVAL << "): ";
                std::string intervalStr;
                std::getline(std::cin, intervalStr);
                
                int interval;
                if (intervalStr.empty()) {
                    interval = DEFAULT_CHECK_INTERVAL;
                } else {
                    try {
                        interval = std::stoi(intervalStr);
                        if (interval < 1) interval = DEFAULT_CHECK_INTERVAL;
                    } catch (...) {
                        interval = DEFAULT_CHECK_INTERVAL;
                    }
                }
                
                startMonitoring(interval);
                break;
            }
                
            default:
                std::cout << "Invalid choice. Please try again.\n";
                break;
        }
    }
    
    return 0;
}
