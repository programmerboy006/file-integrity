#!/bin/bash

# Compile the program
g++ file_integrity_monitor.cpp -o file_monitor -pthread

# Create test files
echo "This is test file 1 for the monitoring test." > monitor_test1.txt
echo "This is test file 2 for the monitoring test." > monitor_test2.txt

# Create an expected input for adding files to monitoring
cat > expected_input.txt << END
3
monitor_test1.txt
3
monitor_test2.txt
5
7
END

# Run the program to add the files and list them
./file_monitor < expected_input.txt

# Show the monitoring list file
echo -e "\nMonitored files list:"
cat monitored_files.txt

# Show the hash database
echo -e "\nHash database contents:"
cat file_hashes.db

echo -e "\nNow you can run './file_monitor' and select option 6 to start monitoring."
echo -e "Then modify monitor_test1.txt or monitor_test2.txt to see the alerts."
echo -e "\nTest commands:"
echo "echo 'This file was modified!' >> monitor_test1.txt"
echo -e "\nTo test, run these commands in separate terminals:"
echo "1. ./file_monitor            (start the monitor)"
echo "2. echo 'Modified!' >> monitor_test1.txt   (in another terminal)"
