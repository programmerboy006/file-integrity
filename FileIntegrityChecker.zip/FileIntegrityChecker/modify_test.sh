#!/bin/bash

# Modify a file while monitoring is running
echo "Modifying monitor_test1.txt..."
echo "This file was modified!" >> monitor_test1.txt
echo "Modification completed."
