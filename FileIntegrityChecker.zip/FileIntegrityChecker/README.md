# File Integrity Checker and Monitor

A robust C++ command-line application for file integrity verification using CRC32 hashing. This application can detect unauthorized file modifications and provide real-time monitoring of critical files.

## Features

- **Generate and Save File Hashes**: Compute checksums of files and store them for future verification.
- **Verify File Integrity**: Compare current file hash with previously saved hash to detect modifications.
- **Real-time File Monitoring**: Set up continuous monitoring of specific files with alerts for unauthorized changes.
- **Support for Multiple Files**: Monitor any number of files simultaneously.
- **Configurable Monitoring Interval**: Set custom time intervals for checking file modifications.

## Components

The project consists of two main applications:

1. **File Integrity Checker** (`integrity_checker`): Basic tool for manual hash generation and verification.
2. **File Integrity Monitor** (`file_monitor`): Advanced tool with real-time monitoring capabilities.

## Getting Started

### Prerequisites

- C++ compiler with C++17 support (g++ recommended)
- pthread library (for the monitoring functionality)

### Building the Project

Compile the file integrity checker:
```
g++ file_integrity_checker_crc.cpp -o integrity_checker
```

Compile the file monitor (with thread support):
```
g++ file_integrity_monitor.cpp -o file_monitor -pthread
```

### Using the File Integrity Checker

The basic checker provides a simple menu-driven interface:

1. **Generate & Save Hash**: Compute and store a file's hash.
2. **Verify File Integrity**: Check if a file has been modified since its hash was saved.
3. **Exit**: Quit the program.

Example usage:
```
./integrity_checker
```

### Using the File Integrity Monitor

The monitor adds real-time monitoring capabilities:

1. **Generate & Save Hash**: Compute and store a file's hash.
2. **Verify File Integrity**: Check if a file has been modified.
3. **Add File to Monitoring**: Add a file to the monitoring list.
4. **Remove File from Monitoring**: Remove a file from the monitoring list.
5. **List Monitored Files**: Show all files being monitored.
6. **Start Real-time Monitoring**: Begin watching the monitored files for changes.
7. **Exit**: Quit the program.

Example usage:
```
./file_monitor
```

#### Adding Files to Monitor

Choose option 3 and enter the file path. The application will:
- Compute and save the hash if it doesn't exist
- Add the file to the monitoring list

#### Starting Monitoring

Choose option 6 to start real-time monitoring. When a modification is detected:
- The application will alert you with details of the modified file
- You'll have the option to update the saved hash for the modified file
- Monitoring continues until you press Ctrl+C

## Technical Details

### Hash Storage

File hashes are saved in `file_hashes.db` with the following format:
```
/absolute/path/to/file1
hash1
/absolute/path/to/file2
hash2
```

### Monitoring List

Monitored files are stored in `monitored_files.txt` with one absolute file path per line.

### Hashing Algorithm

This implementation uses CRC32 for demonstration purposes. For production use, consider implementing a stronger cryptographic hash algorithm like SHA-256.

## Example Test Script

A test script is included to demonstrate the monitoring functionality:

```
./monitor_test.sh
```

This script:
1. Compiles the file monitor
2. Creates test files
3. Adds the test files to the monitoring list
4. Displays instructions for testing the monitoring function

To test the monitoring:
1. Run `./file_monitor` and select option 6 to start monitoring
2. In another terminal, modify a test file with `./modify_test.sh`
3. Observe the alerts in the monitoring terminal

## Notes

- Use absolute paths when adding files for more reliable operation
- The application requires read access to the monitored files
- Monitoring occurs at the specified interval (default: 5 seconds)