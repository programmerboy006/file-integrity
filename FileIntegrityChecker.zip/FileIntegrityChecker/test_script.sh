#!/bin/bash

# Test script for file integrity checker

echo "=== File Integrity Checker Demo ==="
echo

# Compile if not already compiled
if [ ! -f "integrity_checker" ]; then
    echo "Compiling integrity_checker..."
    g++ file_integrity_checker_crc.cpp -o integrity_checker
fi

# Create a test file
echo "Original content of test_file.txt:"
cat test_file.txt
echo

# Generate hash for the test file using automatic input
echo -e "1\ntest_file.txt\n3\n" | ./integrity_checker
echo

# Show the hash database
echo "Hash database contents:"
cat file_hashes.db
echo

# Modify the test file
echo "Modifying test_file.txt..."
echo "This file has been modified!" >> test_file.txt
echo "New content of test_file.txt:"
cat test_file.txt
echo

# Verify the file integrity using automatic input
echo "Verifying file integrity after modification:"
echo -e "2\ntest_file.txt\n3\n" | ./integrity_checker
echo

echo "=== End of Demo ==="
